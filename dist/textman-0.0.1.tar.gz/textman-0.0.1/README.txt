This Package is motivated as a Text Data Manipulator
Following Files:
main.py -> Contains Running parameters of the Library
__init__.py -> An empty python file
vocabulary.py -> Contains function for vocabulary management
translator.py -> Contains functions for text data Translation
analyser.py -> Contains function for text data analysis
modifier.py -> Contains functions for modifying text data
setup.py -> Contains Setup Configuration Data

CHANGELOG.txt -> Contains Version History of the Library
LICENSE.txt -> License for the release of the package
MANIFEST.ini -> Contains different filetypes required for the Package
